package TeamPL;

/** Puzzle creates and displays the slide puzzle */
public class Puzzle { 
	public static void main(String[] args) { 
		Text input = new Text();
	}
}