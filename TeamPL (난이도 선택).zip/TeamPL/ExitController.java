package TeamPL;

import java.awt.event.*;

public class ExitController extends WindowAdapter {
	public void windowClosing(WindowEvent e) {
		System.exit(0); 
	}
}